package com.turtywurty.foodmod.util.interfaces;

public interface IHasModel 
{
	public void registerModels();
}
